# HAND//FX Native Zero-Lag Lab

Native Android rewrite of the HAND//FX browser prototype.

## Latency architecture

- CameraX preview is independent from tracking/rendering.
- ImageAnalysis uses `STRATEGY_KEEP_ONLY_LATEST`: stale camera frames are dropped instead of queued.
- MediaPipe Hand Landmarker runs in `LIVE_STREAM` / `detectAsync` mode.
- Rendering is a continuously running OpenGL ES 3 overlay and never waits for inference.
- Each landmark gets a velocity estimate; the renderer predicts the latest landmark to the current render frame, capped at 38 ms to avoid wild overshoot.
- Front preview is mirrored in the renderer, so FX stays visually attached.
- Face tracking is intentionally absent.

## Current effects

- V5.3-style open/semi-bent fingertip selection baseline.
- Normal fingertip polygon.
- Robust double-clap toggle.
- Spell-only mode with orange / amber / white-hot multi-ring sigil.

## Next renderer phase

Replace/augment the GLES overlay with Vulkan and shader-based FX composer (iridescence, liquid holo, electric, portal tunnel, bloom) after measuring real-device end-to-end latency.
